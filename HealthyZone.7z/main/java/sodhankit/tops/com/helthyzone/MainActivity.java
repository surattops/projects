package sodhankit.tops.com.helthyzone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements BlankFragment.I1 {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        BlankFragment fragment = new BlankFragment();

        getSupportFragmentManager().beginTransaction().add(R.id.frame_layout, fragment).commit();

    }

    @Override
    public void activityMethod() {

    }

}

