package sodhankit.tops.com.digitalsociety.memberpanel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import sodhankit.tops.com.digitalsociety.R;
import sodhankit.tops.com.digitalsociety.model.Complain;
import sodhankit.tops.com.digitalsociety.model.Member;


/**
 * A simple {@link Fragment} subclass.
 */
public class NewComplaintFragment extends Fragment {

    EditText etTitle, etDescription;
    Button btnSubmit;
    ImageButton btnImage;

    public NewComplaintFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_new_complaint, container, false);
        // Inflate the layout for this fragment
        initView(view);
        return view;
    }

    private void initView(View view) {
        etTitle=(EditText)view.findViewById(R.id.etTitle);
        etDescription=(EditText)view.findViewById(R.id.etDescription);
        btnImage=(ImageButton) view.findViewById(R.id.btnImage);
        btnSubmit=(Button) view.findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title=etTitle.getText().toString();
                String description=etDescription.getText().toString();
                if(title.isEmpty() || description.isEmpty())
                {
                    Toast.makeText(getActivity(), "Fill All Details !!!", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveComplain();
            }
        });

        btnImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    private void saveComplain() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        Complain complain=new Complain();
        complain.setTitle(etTitle.getText().toString());
        complain.setDescription(etDescription.getText().toString());
        complain.setDate(DateFormat.getDateTimeInstance().format(new Date()));
        complain.setId(user.getEmail());
        // FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
        String key=mDatabase.child("complain").push().getKey();
        mDatabase.child("complain")
                .child(key)
                .setValue(complain);

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //Member user = dataSnapshot.getValue(Member.class);
                //Log.d("MEMBER", "Value is: " + user.getContact());
                Toast.makeText(getActivity(), "Complain Saved Successfull...", Toast.LENGTH_SHORT).show();
               /* Fragment fragment=new LoginFragment();
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout,fragment)
                        .commit();*/
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(getActivity(), "Failed to Save value.", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
