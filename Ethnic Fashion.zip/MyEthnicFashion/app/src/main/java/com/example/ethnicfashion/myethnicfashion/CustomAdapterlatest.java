package com.example.ethnicfashion.myethnicfashion;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class CustomAdapterlatest extends BaseAdapter {

	Context c;
	ArrayList<Integer> listid;
	public CustomAdapterlatest(Context c, ArrayList<Integer> listid, ArrayList<String> list, ArrayList<String> listimg) {
		super();
		this.c = c;
		this.listid = listid;
		this.list = list;
		this.listimg = listimg;
	}

	ArrayList<String> list;
	ArrayList<String> listimg;
	private Bitmap mIcon_val;
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int pos) {
		// TODO Auto-generated method stub
		return list.get(pos);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public View getView(int pos, View convertView, ViewGroup container) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflater.inflate(R.layout.lat_grid_single, container,false);
		
		TextView list_tvname = (TextView)v.findViewById(R.id.item_text);
		TextView list_id = (TextView)v.findViewById(R.id.item_id);
		ImageView list_ivimg = (ImageView)v.findViewById(R.id.item_image);
		list_id.setText(String.valueOf(listid.get(pos)));
		list_tvname.setText(list.get(pos));
		
	
		  URL newurl;
				try {
					  newurl = new URL("http://192.168.1.211:8080/EthnicIndianFashion/image/"+listimg.get(pos));
					  
						new ImageFromUrl(list_ivimg).execute(newurl);
			        } catch (IOException e) {
			            e.printStackTrace();
			            System.out.printf("Exception", e.getMessage());
			            return null;
			        }
		      
		return v;
	}

	class ImageFromUrl extends AsyncTask<URL, Void, Bitmap>
	{
		ImageView list_ivimg;
		ImageFromUrl(ImageView list_ivimg)
		{
			this.list_ivimg=list_ivimg;
		}

		@Override
		protected Bitmap doInBackground(URL... params) {
			try {
				HttpURLConnection connection = (HttpURLConnection) params[0].openConnection();
				connection.setDoInput(true);
				connection.connect();
				InputStream input = connection.getInputStream();
				Bitmap bitmap = BitmapFactory.decodeStream(input);
				bitmap = Bitmap.createScaledBitmap(mIcon_val, 80, 80, false);//This is only if u want to set the image size.
				return bitmap;
			}catch (Exception ex)
			{

			}
			return null;
		}

		@Override
		protected void onPostExecute(Bitmap bitmap) {
			super.onPostExecute(bitmap);
			if(bitmap!=null)
				list_ivimg.setImageBitmap(bitmap);
		}
	}



	public CustomAdapterlatest(Context c, ArrayList<String> list, ArrayList<String> listimg) {
		super();
		this.c = c;
		this.listimg = listimg;
		this.list = list;
	}

}
