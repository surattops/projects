package com.example.ethnicfashion.myethnicfashion;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SubcategoryActivity extends AppCompatActivity {

    private TextView tv;
    int selecteditemid = 0;
    private ArrayList<String> listimg;
    private ArrayList<String> list;
    private ArrayList<Integer> listcatid;
    private ArrayList<Integer> listsubcatid;
    private StringBuffer sb;
    private String su;
    private String imgname;
    private int subcatid;
    private ListView lv;
    private int catid1;
    private int subcatid2;
    private int catid;
    private Button btnsort;
    private Button btnfilter;
    ExpandableListView expListView;
    List<String> listDataHeader;
    HashMap<String, List<String>> listDataChild;
    int value1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcategory);

        Bundle b = getIntent().getExtras();
        //	String value = b.getString("itemid");
        value1 = b.getInt("itemid");

        lv = (ListView)findViewById(R.id.listView1);
        getSubCategoryDetails("http://192.168.1.211:8080/webservice1/wb1.php?catid="+value1);

        btnsort = (Button)findViewById(R.id.btnsort);
        btnfilter = (Button)findViewById(R.id.btnfilter);


        btnsort.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                final Dialog dialog = new Dialog(SubcategoryActivity.this);
                dialog.setContentView(R.layout.custom);
                dialog.setTitle("Select sort by...");

                // set the custom dialog components - text, image and button
                TextView text = (TextView) dialog.findViewById(R.id.text);

                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        btnfilter.setOnClickListener(new View.OnClickListener() {

            private CheckBox ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11;
            private TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10, tv11;

            @Override
            public void onClick(View v) {

                final Dialog dialog = new Dialog(SubcategoryActivity.this);
                dialog.setContentView(R.layout.custom2);
                dialog.setTitle("Select sort by...");

                // set the custom dialog components - text, image and button
                ch1 = (CheckBox) dialog.findViewById(R.id.checkBox1);
                ch2 = (CheckBox) dialog.findViewById(R.id.checkBox2);
                ch3 = (CheckBox) dialog.findViewById(R.id.checkBox3);
                ch4 = (CheckBox) dialog.findViewById(R.id.checkBox4);
                ch5 = (CheckBox) dialog.findViewById(R.id.checkBox5);
                ch6 = (CheckBox) dialog.findViewById(R.id.checkBox6);
                ch7 = (CheckBox) dialog.findViewById(R.id.checkBox7);
                ch8 = (CheckBox) dialog.findViewById(R.id.checkBox8);
                ch9 = (CheckBox) dialog.findViewById(R.id.checkBox9);
                ch10 = (CheckBox) dialog.findViewById(R.id.checkBox10);
                ch11 = (CheckBox) dialog.findViewById(R.id.checkBox11);


                tv1 = (TextView) dialog.findViewById(R.id.textView1);
                tv2 = (TextView) dialog.findViewById(R.id.textView2);
                tv3 = (TextView) dialog.findViewById(R.id.textView3);
                tv4 = (TextView) dialog.findViewById(R.id.textView4);
                tv5 = (TextView) dialog.findViewById(R.id.textView5);
                tv6 = (TextView) dialog.findViewById(R.id.textView6);
                tv7 = (TextView) dialog.findViewById(R.id.textView7);
                tv8 = (TextView) dialog.findViewById(R.id.textView8);
                tv9 = (TextView) dialog.findViewById(R.id.textView9);
                tv10 = (TextView) dialog.findViewById(R.id.textView10);
                tv11 = (TextView) dialog.findViewById(R.id.textView11);

                Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                // if button is clicked, close the custom dialog
                dialogButton.setOnClickListener(new View.OnClickListener() {


                    @Override
                    public void onClick(View v) {
                        String selected = "";
                        if (ch1.isChecked()) {
                            selected = selected + tv1.getText();
                        }
                        if (ch2.isChecked()) {
                            selected = selected + "," + tv2.getText();
                        }
                        if (ch3.isChecked()) {
                            selected = selected + "," + tv3.getText();
                        }
                        if (ch4.isChecked()) {
                            selected = selected + "," + tv4.getText();
                        }
                        if (ch5.isChecked()) {
                            selected = selected + "," + tv5.getText();
                        }
                        if (ch6.isChecked()) {
                            selected = selected + "," + tv6.getText();
                        }
                        if (ch7.isChecked()) {
                            selected = selected + "," + tv7.getText();
                        }
                        if (ch8.isChecked()) {
                            selected = selected + "," + tv8.getText();
                        }
                        if (ch9.isChecked()) {
                            selected = selected + "," + tv9.getText();
                        }
                        if (ch10.isChecked()) {
                            selected = selected + "," + tv10.getText();
                        }
                        if (ch11.isChecked()) {
                            selected = selected + "," + tv11.getText();
                        }
                        System.out.println("the value of i is:=================================" + selected);
                        dialog.dismiss();
                    }
                });

                dialog.show();


            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                //	  String value = (String)parent.getItemAtPosition(position);
                int value1 = listcatid.get(position);
                int value2 = listsubcatid.get(position);
                Intent i1 = new Intent(SubcategoryActivity.this, ProductActivity.class);
                i1.putExtra("intcatid", value1);
                i1.putExtra("intsubcatid", value2);
                startActivity(i1);
            }
        });
    }

    void getSubCategoryDetails(String url)
    {
            (new AsyncTask<String, Void, String>()
            {
                ProgressDialog pd;

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    pd=ProgressDialog.show(SubcategoryActivity.this,"Wait","Loading");
                }

                @Override
                protected String doInBackground(String... params) {
                    JSONParser jp = new JSONParser();
                    String jstring = jp.getJSONData(params[0]);
                    return jstring;
                }

                @Override
                protected void onPostExecute(String jstring) {
                    super.onPostExecute(jstring);
                    pd.dismiss();
                    // Log.i("JsonString",jstring);
                    try {
                        listimg = new ArrayList<String>();
                        list = new ArrayList<String>();
                        listcatid = new ArrayList<Integer>();
                        listsubcatid = new ArrayList<Integer>();
                        JSONObject juser = new JSONObject(jstring);
                        JSONArray jarray =  juser.getJSONArray("subcategory");
                        for (int i = 0; i < jarray.length(); i++)
                        {
                            JSONObject user = jarray.getJSONObject(i);
                            catid1 = user.getInt("catid");
                            subcatid2 = user.getInt("subcatid");
                            if(catid1 == value1)
                            {
                                su=user.getString("subcatname");
                                imgname = user.getString("subcatimg");
                                subcatid = user.getInt("subcatid");
                                catid = user.getInt("catid");
                                list.add(su);
                                listimg.add(imgname);
                                listcatid.add(catid);
                                listsubcatid.add(subcatid);
                            }
                        }
                        lv.setAdapter(new CustomAdapter2(getApplicationContext(), list, listimg));
                        setListViewHeightBasedOnItems(lv);
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }).execute(url);

    }
    public boolean setListViewHeightBasedOnItems(ListView listView) {

        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter != null) {

            int numberOfItems = listAdapter.getCount();

            // Get total height of all items.
            int totalItemsHeight = 0;
            for (int itemPos = 0; itemPos < numberOfItems; itemPos++) {
                View item = listAdapter.getView(itemPos, null, listView);
                item.measure(0, 0);
                totalItemsHeight += item.getMeasuredHeight();
            }

            // Get total height of all item dividers.
            int totalDividersHeight = listView.getDividerHeight() *
                    (numberOfItems - 1);

            // Set list height.
            ViewGroup.LayoutParams params = listView.getLayoutParams();
            params.height = totalItemsHeight + totalDividersHeight;
            listView.setLayoutParams(params);
            listView.requestLayout();

            return true;

        } else {
            return false;
        }
    }
}
