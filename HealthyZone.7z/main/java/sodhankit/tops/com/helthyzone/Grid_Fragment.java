package sodhankit.tops.com.helthyzone;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Grid_Fragment extends Fragment {

    TextView tvpeople,tvattend,tvtips,tvproduct;

    public Grid_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_grid_, container, false);
        tvpeople = (TextView)view.findViewById(R.id.tvpeople);
        tvattend = (TextView)view.findViewById(R.id.tvattend);
        tvtips = (TextView)view.findViewById(R.id.tvtips);
        tvproduct = (TextView)view.findViewById(R.id.tvproduct);

        tvpeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Recycle_Fragment fragment = new Recycle_Fragment();
                getActivity().
                        getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Grid_Fragment.class.getName())
                        .replace(R.id.content_nevigation,fragment)
                        .commit();
            }
        });

        tvproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ProductFragment fragment = new ProductFragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Grid_Fragment.class.getName())
                        .replace(R.id.content_nevigation,fragment)
                        .commit();
            }
        });


        tvtips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TipsFragment fragment = new TipsFragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Grid_Fragment.class.getName())
                        .replace(R.id.content_nevigation,fragment)
                        .commit();

            }
        });


        tvattend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Attendance_Fragment fragment = new Attendance_Fragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Grid_Fragment.class.getName())
                        .replace(R.id.content_nevigation,fragment)
                        .commit();

            }
        });


        return  view;
    }

}
