package com.example.ethnicfashion.myethnicfashion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {

	Context c;
	ArrayList<Integer> listid;
	public CustomAdapter(Context c, ArrayList<Integer> listid, ArrayList<String> list, ArrayList<String> listimg) {
		super();
		this.c = c;
		this.listid = listid;
		this.list = list;
		this.listimg = listimg;
	}

	ArrayList<String> list;
	ArrayList<String> listimg;
	private Bitmap mIcon_val;
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int pos) {
		// TODO Auto-generated method stub
		return list.get(pos);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public View getView(int pos, View convertView, ViewGroup container) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflater.inflate(R.layout.cat_layout, container,false);
		
		TextView list_tvcatname = (TextView)v.findViewById(R.id.tvcatname);
		ImageView list_ivcatimg = (ImageView)v.findViewById(R.id.ivcatimg);
		TextView list_tvcatid = (TextView)v.findViewById(R.id.tvcatid);
		list_tvcatid.setText(String.valueOf(listid.get(pos)));
		list_tvcatname.setText(list.get(pos));
		
	
		  URL newurl;
				try {
					  newurl = new URL("http://192.168.1.211:8080/EthnicIndianFashion/image/"+listimg.get(pos));
					  
			            HttpURLConnection connection = (HttpURLConnection) newurl
			                    .openConnection();
			            connection.setDoInput(true);
			            connection.connect();
			            InputStream input = connection.getInputStream();
			            mIcon_val= BitmapFactory.decodeStream(input);
			            mIcon_val = Bitmap.createScaledBitmap(mIcon_val, 80, 80, false);//This is only if u want to set the image size.
			            list_ivcatimg.setImageBitmap(mIcon_val);
			        } catch (IOException e) {
			            e.printStackTrace();
			            System.out.printf("Exception", e.getMessage());
			            return null;
			        }
		      
		return v;
	}



	public CustomAdapter(Context c, ArrayList<String> list, ArrayList<String> listimg) {
		super();
		this.c = c;
		this.listimg = listimg;
		this.list = list;
	}

}
