package practice.sodhankit.com.animation;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private ImageView img;
    private ToggleButton tb;
    private ImageView img1;
    private Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        img=(ImageView)findViewById(R.id.img);
        img1=(ImageView)findViewById(R.id.img1);
        btn1=(Button)findViewById(R.id.btn1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img1.setImageResource(R.drawable.logo);
                Animation anim = AnimationUtils.loadAnimation(MainActivity.this,R.anim.flip);
                img1.setAnimation(anim);

            }
        });

        tb = (ToggleButton) findViewById(R.id.btn);

        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                img.setBackgroundResource(R.anim.slider);

                AnimationDrawable anim = (AnimationDrawable) img.getBackground();

                if(b) {
                    anim.stop();
                }
                else {
                    anim.start();
                }
            }
        });
    }
}
