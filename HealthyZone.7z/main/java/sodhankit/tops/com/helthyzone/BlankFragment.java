package sodhankit.tops.com.helthyzone;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends Fragment {



    public BlankFragment() {
        // Required empty public constructor
           }




    interface I1
    {
        void activityMethod();
    }
    I1 i1Reference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_blank, container, false);
        // Inflate the layout for this fragment

      /*  btnlogin=(Button)view.findViewById(R.id.btnlogin);
        btregis = (Button) view.findViewById(R.id.btregis);
        btregis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FormFragment fragment = new FormFragment();

                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.frame_layout,fragment).commit();
            }


        });


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LoginFragment fragment = new LoginFragment();

                getActivity().getSupportFragmentManager().beginTransaction().
                        replace(R.id.frame_layout,fragment).commit();

            }
        });*/

        LoginFragment fragment = new LoginFragment();
                 getActivity()
                .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame_layout,fragment)
                .commit();
        return view;
    }


}
