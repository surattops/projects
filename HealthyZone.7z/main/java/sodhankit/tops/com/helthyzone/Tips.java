package sodhankit.tops.com.helthyzone;

/**
 * Created by Pratik Lakkad on 22-04-2017.
 */

public class Tips
{
    public static final String BASE_URL = "http://192.168.43.126/admin/tips.php?";
    public static final String SELECT = "selecttips";

    public static final String INSERT = "inserttips";


}
