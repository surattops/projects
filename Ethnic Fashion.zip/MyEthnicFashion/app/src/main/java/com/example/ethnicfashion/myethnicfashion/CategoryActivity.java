package com.example.ethnicfashion.myethnicfashion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class CategoryActivity extends AppCompatActivity {

    private StringBuffer sb;
    TextView tvcatname;
    ImageView ivcatimg;
    private Bitmap mIcon_val;
    private ArrayList<Integer> listid;
    private ArrayList<String> list;
    private ArrayList<String> listimg;
    private String su;
    private String imgname;
    private ListView lv;
    Object listItem;
    private int catid;
    private int catidgd;
    int selecteditemid = 0;
    private GridView gv;
    private String sugd;
    private String imgnamegd;
    private ArrayList<String> listgd;
    private ArrayList<Integer> listidgd;
    private ArrayList<String> listimggd;
    private StringBuffer sb1;
    private AutoCompleteTextView textView;
    private ImageView btnsrc;



    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private ArrayAdapter<String> mAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mActivityTitle;
    private ArrayList<Integer> listid3;
    private ArrayList<String> list3;
    private StringBuffer sb3;
    private String su3;
    private int catid3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);


        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        mDrawerList = (ListView)findViewById(R.id.navList);
        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        lv = (ListView)findViewById(R.id.listView1);

        gv = (GridView)findViewById(R.id.gridView1);


        mActivityTitle = getTitle().toString();

        addDrawerItems();
        setupDrawer();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        getProductDetails("http://192.168.1.211:8080/webservice1/wb1.php?product");

        getCategoryDetails("http://192.168.1.211:8080/webservice1/wb1.php?all");

        getLastProductDetails("http://192.168.1.211:8080/webservice1/wb1.php?lastproduct");

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                //String value = (String)parent.getItemAtPosition(position);
                int value = listid.get(position);
                Intent i1 = new Intent(CategoryActivity.this, SubcategoryActivity.class);
                i1.putExtra("itemid", value);
                startActivity(i1);
            }


        });
    }

    void getProductDetails(String url)
    {
        (new AsyncTask<String, Void, String>()
        {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd=ProgressDialog.show(CategoryActivity.this,"Wait","Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                JSONParser jp = new JSONParser();
                String jstring = jp.getJSONData(params[0]);
                return jstring;
            }

            @Override
            protected void onPostExecute(String jstring) {
                super.onPostExecute(jstring);
                pd.dismiss();
                // Log.i("JsonString",jstring);
                try {
                    ArrayList<String> listdata = new ArrayList<String>();
                    JSONObject login = new JSONObject(jstring);
                    JSONArray jarray =  login.getJSONArray("product");
                    for (int i = 0; i < jarray.length(); i++) {
                        JSONObject user = jarray.getJSONObject(i);
                        String su=user.getString("prodname");

                        listdata.add(su);
                    }
                    textView = (AutoCompleteTextView) findViewById(R.id.tvauto);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                            android.R.layout.simple_dropdown_item_1line, listdata);
                    textView.setAdapter(adapter);


                    btnsrc = (ImageView)findViewById(R.id.item_image);
                    btnsrc.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub

                        }
                    });
                }
                catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    Log.i("Error", e.toString());
                }
            }
        }).execute(url);

    }

    void getCategoryDetails(String url)
    {
        (new AsyncTask<String, Void, String>()
        {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd=ProgressDialog.show(CategoryActivity.this,"Wait","Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                JSONParser jp = new JSONParser();
                String jstring = jp.getJSONData(params[0]);
                return jstring;
            }

            @Override
            protected void onPostExecute(String jstring) {
                super.onPostExecute(jstring);
                pd.dismiss();
                // Log.i("JsonString",jstring);
                try {
                    list=new ArrayList<String>();
                    listid=new ArrayList<Integer>();
                    listimg=new ArrayList<String>();

                    JSONObject juser1 = new JSONObject(jstring);
                    JSONArray jarray1 =  juser1.getJSONArray("category");
                    for (int i = 0; i < jarray1.length(); i++)
                    {
                        JSONObject user1 = jarray1.getJSONObject(i);
                        su=user1.getString("catname");
                        imgname = user1.getString("catimg");
                        catid = user1.getInt("catid");
                        list.add(su);
                        listid.add(catid);
                        listimg.add(imgname);
                    }
                    lv.setAdapter(new CustomAdapter(getApplicationContext(), listid, list, listimg));
                    setListViewHeightBasedOnItems(lv);
                } catch (JSONException e) {
//		// TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }).execute(url);

    }

    void getLastProductDetails(String url)
    {
        (new AsyncTask<String, Void, String>()
        {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd=ProgressDialog.show(CategoryActivity.this,"Wait","Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                JSONParser jp = new JSONParser();
                String jstring = jp.getJSONData(params[0]);
                return jstring;
            }

            @Override
            protected void onPostExecute(String jstring) {
                super.onPostExecute(jstring);
                pd.dismiss();
                // Log.i("JsonString",jstring);
                try {
                    listgd=new ArrayList<String>();
                    listidgd=new ArrayList<Integer>();
                    listimggd=new ArrayList<String>();

                    JSONObject juser1 = new JSONObject(jstring);
                    JSONArray jarray1 =  juser1.getJSONArray("product");
                    for (int i = 0; i < jarray1.length(); i++)
                    {
                        JSONObject user1 = jarray1.getJSONObject(i);
                        sugd=user1.getString("prodname");
                        imgnamegd = user1.getString("prodimgname1");
                        catidgd = user1.getInt("prodid");
                        listgd.add(sugd);
                        listidgd.add(catidgd);
                        listimggd.add(imgnamegd);
                    }
                    gv.setAdapter(new CustomAdapterlatest(getApplicationContext(),listidgd,listgd,listimggd));
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }).execute(url);

    }


    private void addDrawerItems() {
        String[] osArray = { "Android", "iOS", "Windows", "OS X", "Linux" };
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, osArray);
        mDrawerList.setAdapter(mAdapter);

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(CategoryActivity.this, "Time for an upgrade!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle("Navigation!");
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    public static boolean setListViewHeightBasedOnItems(ListView listView) {

        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter != null) {

            int numberOfItems = listAdapter.getCount();

            // Get total height of all items.
            int totalItemsHeight = 0;
            for (int itemPos = 0; itemPos < numberOfItems; itemPos++) {
                View item = listAdapter.getView(itemPos, null, listView);
                item.measure(0, 0);
                totalItemsHeight += item.getMeasuredHeight();
            }

            // Get total height of all item dividers.
            int totalDividersHeight = listView.getDividerHeight() *
                    (numberOfItems - 1);

            // Set list height.
            ViewGroup.LayoutParams params = listView.getLayoutParams();
            params.height = totalItemsHeight + totalDividersHeight;
            listView.setLayoutParams(params);
            listView.requestLayout();

            return true;

        } else {
            return false;
        }

    }
}
