package sodhankit.tops.com.helthyzone;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class TipsFragment extends Fragment implements ServerCallAsyncTask.OnAsyncJSONResponse {

    private static final int INSERT_TIPS = 1;

    EditText ettips;
    Button btnsend;

    public TipsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tips, container, false);

        ettips = (EditText) view.findViewById(R.id.ettips);
        btnsend = (Button) view.findViewById(R.id.btnsend);


        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ettips.getText().toString().length() == 0) {
                    Toast.makeText(getContext(), "Please Enter Reference", Toast.LENGTH_LONG).show();
                    ettips.setError("Please Enter Reference");
                    return;
                }
                String tips = ettips.getText().toString();


                final String url = Tips.BASE_URL+ Tips.INSERT;


                HashMap<String, String> hashmap = new HashMap();

                hashmap.put("Tips_details", tips);


                ServerCallAsyncTask asyncTask = new ServerCallAsyncTask(TipsFragment.this, getActivity(), url, hashmap, INSERT_TIPS);
                asyncTask.execute();


            }
        });

        return view;
    }

    @Override
    public void asyncGetSMSResponse(String response, int flag)
    {
        if (flag == INSERT_TIPS) {
            Toast.makeText(getActivity(), "Data Saved", Toast.LENGTH_LONG).show();

            if (response.trim().length() > 0) {
                //Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                Grid_Fragment fragment = new Grid_Fragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Grid_Fragment.class.getName())
                        .replace(R.id.content_nevigation, fragment)
                        .commit();
            }
            else
            {
                Toast.makeText(getActivity(), " Failed to insert Tips!!!", Toast.LENGTH_SHORT).show();
            }


        }
    }
}