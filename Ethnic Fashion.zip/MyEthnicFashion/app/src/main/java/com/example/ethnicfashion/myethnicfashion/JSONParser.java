package com.example.ethnicfashion.myethnicfashion;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONArray;


public class JSONParser {

	private StringBuffer sb;
	private JSONArray jarray;
	private StringBuilder sbuiler;

	public JSONParser() {
		// TODO Auto-generated constructor stub
	}
	
	public String getJSONData(String url)
	{
		try {

			OkHttpClient client = new OkHttpClient();

			Request request = new Request.Builder().url(url).build();

			Response response = client.newCall(request).execute();

			return response.body().string();
			//create your client
		}
		catch (Exception ex)
		{
			return ex.toString();
		}

	}
}
