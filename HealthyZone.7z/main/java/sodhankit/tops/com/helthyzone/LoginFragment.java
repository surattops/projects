package sodhankit.tops.com.helthyzone;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.rengwuxian.materialedittext.MaterialEditText;
import com.rey.material.widget.Button;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment implements ServerCallAsyncTask.OnAsyncJSONResponse {


    private static final int LOGIN_VERIFICATION = 1;

    public LoginFragment() {
        // Required empty public constructor
    }

        MaterialEditText etnumber,etpaswd;
        Button btnlogin;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        Toolbar toolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
//        toolbar.getMenu().add(0,2,2,"added");

        View view = inflater.inflate(R.layout.fragment_login, container, false);

        btnlogin = (Button)view.findViewById(R.id.btnlogin);
        etnumber = (MaterialEditText)view.findViewById(R.id.etnumber);
        etpaswd = (MaterialEditText)view.findViewById(R.id.etpaswd);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /**/
                String url=ServerCallAsyncTask.BASE_URL+"login_verification";
                HashMap<String,String> hashMap=new HashMap();
                hashMap.put("name",etnumber.getText().toString());
                hashMap.put("pass",etpaswd.getText().toString());
                
                ServerCallAsyncTask asyncTask=new ServerCallAsyncTask(LoginFragment.this,getActivity(),url,hashMap,LOGIN_VERIFICATION);
                asyncTask.execute();
            }
        });
        checkSession();
        return view;
    }

    private void checkSession() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MyPreference", Context.MODE_PRIVATE);
        String session = sharedPreferences.getString("LOGIN", "");
        if(!session.equals(""))
        {
            Grid_Fragment fragment = new Grid_Fragment();
            getActivity()
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.content_nevigation,fragment)
                    .commit();
        }

    }

    @Override
    public void asyncGetSMSResponse(String response, int flag) {
        if(flag==LOGIN_VERIFICATION)
        {
            if(response.trim().length()>0)
            {
                SharedPreferences sharedPreferences=getActivity().getSharedPreferences("MyPreference", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString("LOGIN","1");
                editor.commit();

                Toast.makeText(getActivity(), "WELCOME ", Toast.LENGTH_SHORT).show();
                Grid_Fragment fragment = new Grid_Fragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.content_nevigation,fragment)
                        .commit();
            }else
            {
                Toast.makeText(getActivity(), "Login Failed!!!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
