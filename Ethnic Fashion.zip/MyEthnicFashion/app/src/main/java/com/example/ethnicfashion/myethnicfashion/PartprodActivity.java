package com.example.ethnicfashion.myethnicfashion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PartprodActivity extends AppCompatActivity {

    TextView tvcatname;
    ImageView ivcatimg;
    private Bitmap mIcon_val;
    private ArrayList<Integer> listid;
    private ArrayList<String> list;
    private ArrayList<String> listimg;
    private String su;
    private String imgname;
    Object listItem;
    private int catid;
    int selecteditemid = 0;
    private ArrayList<Integer> prodidlist;
    private ArrayList<String> prodnamelist;
    private ArrayList<String> prodimgname1list;
    private ArrayList<String> prodimgname2list;
    private ArrayList<String> prodimgname3list;
    private ArrayList<Integer> fabidlist;
    private ArrayList<Integer> prodqtylist;
    private ArrayList<Integer> prodpricelist;
    private ArrayList<Integer> proddisclist;

    private ArrayList<Integer> bidlist;
    private ArrayList<Integer> cidlist;
    private ArrayList<Integer> sidlist;



    private String prodname;
    private String prodimgname1;
    private String prodimgname2;
    private String prodimgname3;
    private int fabid;
    private int prodqty;
    private int disc;

    private int bid;
    private int sid;
    private int cid;
    private StringBuffer sb;
    private int prodprice;
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partprod);

        lv = (ListView)findViewById(R.id.listView1);
        getProduct("http://192.168.1.211:8080/webservice1/wb1.php?cattid="+10+"&&subcatid="+23);
    }

    void getProduct(String url)
    {
        (new AsyncTask<String, Void, String>()
        {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd=ProgressDialog.show(PartprodActivity.this,"Wait","Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                JSONParser jp = new JSONParser();
                String jstring = jp.getJSONData(params[0]);
                return jstring;
            }

            @Override
            protected void onPostExecute(String jstring) {
                super.onPostExecute(jstring);
                pd.dismiss();
                // Log.i("JsonString",jstring);
                try {
                    prodidlist=new ArrayList<Integer>();
                    prodnamelist=new ArrayList<String>();
                    prodimgname1list=new ArrayList<String>();
                    prodimgname2list=new ArrayList<String>();
                    prodimgname3list=new ArrayList<String>();
                    fabidlist=new ArrayList<Integer>();
                    prodqtylist=new ArrayList<Integer>();
                    prodpricelist=new ArrayList<Integer>();
                    bidlist=new ArrayList<Integer>();
                    sidlist=new ArrayList<Integer>();
                    cidlist=new ArrayList<Integer>();

                    JSONObject juser = new JSONObject(jstring);
                    JSONArray jarray =  juser.getJSONArray("product");

                    for (int i = 0; i < jarray.length(); i++)
                    {
                        JSONObject user = jarray.getJSONObject(i);
                        //catname=user.getString("catname");
                        int prodid=user.getInt("prodid");
                        prodname=user.getString("prodname");
                        prodimgname1=user.getString("prodimgname1");
                        prodimgname2=user.getString("prodimgname2");
                        prodimgname3=user.getString("prodimgname3");
                        fabid = user.getInt("fabid");
                        prodqty = user.getInt("prodqty");
                        prodprice = user.getInt("prodprice");
                        bid = user.getInt("bid");
                        sid = user.getInt("sid");
                        cid = user.getInt("cid");
                        disc = user.getInt("discount");

                        prodidlist.add(prodid);
                        prodnamelist.add(prodname);
                        prodimgname1list.add(prodimgname1);
                        prodimgname2list.add(prodimgname2);
                        prodimgname3list.add(prodimgname3);
                        fabidlist.add(fabid);
                        prodqtylist.add(prodqty);
                        prodpricelist.add(prodprice);
                        bidlist.add(bid);
                        sidlist.add(sid);
                        cidlist.add(cid);

                    }
                    lv.setAdapter(new CustomeAdapterProduct(getApplicationContext(), prodidlist, prodnamelist,
                            prodimgname1list, prodimgname2list, prodimgname3list, fabidlist, prodqtylist, prodpricelist,
                            proddisclist, bidlist, cidlist, sidlist));

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).execute(url);

    }
}
