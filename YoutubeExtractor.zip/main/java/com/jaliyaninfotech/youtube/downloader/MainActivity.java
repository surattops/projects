package com.jaliyaninfotech.youtube.downloader;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.commit451.youtubeextractor.YouTubeExtractionResult;
import com.commit451.youtubeextractor.YouTubeExtractor;
import com.devbrackets.android.exomedia.listener.OnErrorListener;
import com.devbrackets.android.exomedia.listener.OnPreparedListener;
import com.devbrackets.android.exomedia.ui.widget.VideoView;

import java.io.File;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {

    private static final String GRID_YOUTUBE_ID = "9d8wWcJLnFI";

    private static final String STATE_SAVED_POSITION = "saved_position";

    private ImageView imageView;
    private TextView description;
    private EditText etUrl;
//    private VideoView videoView;

    private int savedPosition;
    ImageButton btnDownload;

    private final YouTubeExtractor extractor = YouTubeExtractor.create();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.thumb);
        //videoView = findViewById(R.id.video_view);
        description = findViewById(R.id.description);
        btnDownload=findViewById(R.id.btnDownload);
        etUrl=findViewById(R.id.etUrl);

        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startDownloading();
            }
        });


       /* if (savedInstanceState != null) {
            savedPosition = savedInstanceState.getInt(STATE_SAVED_POSITION, 0);
        }
        videoView.setOnPreparedListener(new OnPreparedListener() {
            @Override
            public void onPrepared() {
                if (videoView == null) {
                    return;
                }

                videoView.setVolume(0);
                videoView.seekTo(savedPosition);
                savedPosition = 0;
                videoView.start();
            }
        });
        videoView.setOnErrorListener(new OnErrorListener() {
            @Override
            public boolean onError(Exception e) {
                e.printStackTrace();
                return false;
            }
        });*/
    }

    private void startDownloading() {
        /*String url=etUrl.getText().toString();
        String videoId=url.substring(url.indexOf("="));
        if(videoId.length()==0)
        {
            Toast.makeText(this, "Please Enter Valid Url", Toast.LENGTH_SHORT).show();
            return;
        }*/
        String videoId=etUrl.getText().toString();
        extractor.extract(videoId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<YouTubeExtractionResult>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                    }

                    @Override
                    public void onSuccess(YouTubeExtractionResult value) {
                        bindVideoResult(value);
                    }

                    @Override
                    public void onError(Throwable e) {
                        MainActivity.this.onError(e);
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
       /* videoView.seekTo(savedPosition);
        videoView.start();*/
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SAVED_POSITION, savedPosition);
    }

    private void onError(Throwable t) {
        t.printStackTrace();
        Toast.makeText(MainActivity.this, "It failed to extract. So sad", Toast.LENGTH_SHORT).show();
    }

    private void bindVideoResult(YouTubeExtractionResult result) {
        Log.d("OnSuccess", "Got a result with the best url: " + result.getBestAvailableQualityVideoUri());
        Glide.with(this)
                .load(result.getBestAvailableQualityThumbUri())
                .into(imageView);
        /*videoView.setVideoURI(result.getBestAvailableQualityVideoUri());*/
        new MyAsyncTask().execute(result.getBestAvailableQualityVideoUri().toString());
    }

    class MyAsyncTask extends AsyncTask<String,Void,String>
    {
        ProgressDialog pd;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd=ProgressDialog.show(MainActivity.this,"Wait","Downloading");
        }

        @Override
        protected String doInBackground(String... strings) {
            File file=Environment.getExternalStorageDirectory();
            file=new File(file,"youtube.mp4");
            //FileDownloader.downloadFile(strings[0],file);
            FileDownloader.DownloadData(strings[0],getApplicationContext());
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
        }
    }

}
