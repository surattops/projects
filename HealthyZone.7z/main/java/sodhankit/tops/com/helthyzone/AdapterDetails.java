package sodhankit.tops.com.helthyzone;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Pratik Lakkad on 25-02-2017.
 */


public class AdapterDetails extends BaseAdapter {
    private ArrayList<Customer> CustomerArrayList;
    private Activity activity;
    boolean attendance;

    public AdapterDetails(ArrayList<Customer> CustomerArrayList, Activity activity, boolean attendance) {
        this.CustomerArrayList = CustomerArrayList;
        this.activity = activity;
        this.attendance=attendance;
    }

    @Override
    public int getCount() {
        return CustomerArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return CustomerArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null)
        {
            convertView=activity.getLayoutInflater().inflate(R.layout.row_items,parent,false);
        }
        CheckBox cbAttendance;
        final TextView tvId, tvname, tvage, tvpno, tvgender;
        View view;
        cbAttendance = (CheckBox) convertView.findViewById(R.id.cbAttendance);
        tvId = (TextView) convertView.findViewById(R.id.tvId);
        tvname = (TextView) convertView.findViewById(R.id.tvname);
        tvage = (TextView) convertView.findViewById(R.id.tvage);
        tvpno = (TextView) convertView.findViewById(R.id.tvpno);
        tvgender = (TextView) convertView.findViewById(R.id.tvgender);
    if(attendance)
    {
        cbAttendance.setVisibility(View.VISIBLE);
        cbAttendance.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    Attendance_Fragment.custId.add(tvId.getText().toString());
                }else
                {
                    Attendance_Fragment.custId.remove(tvId.getText().toString());
                }
            }
        });
    }
        Customer customer=CustomerArrayList.get(position);

        tvId.setText(customer.getCust_id());
        tvname.setText(customer.getCust_name());
        tvage.setText(customer.getCust_age());
        tvpno.setText(customer.getCust_pno());
        tvgender.setText(customer.getCust_gender());

        return convertView;
    }

}

