package com.example.ethnicfashion.myethnicfashion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class CustomAdapter3 extends BaseAdapter {

    Context c;
    private ArrayList<Integer> prodidlist;
    private ArrayList<String> prodnamelist;
    private ArrayList<String> prodimgname1list;
    private ArrayList<String> prodimgname2list;
    private ArrayList<String> prodimgname3list;
    private ArrayList<Integer> fabidlist;
    private ArrayList<Integer> prodqtylist;
    private ArrayList<Integer> prodpricelist;
    private ArrayList<Integer> bidlist;
    private ArrayList<Integer> cidlist;
    private ArrayList<Integer> sidlist;



    private String prodname;
    private String prodimgname1;
    private String prodimgname2;
    private String prodimgname3;
    private int fabid;
    private int prodqty;
    private int bid;
    private int sid;
    private int cid;


    private Bitmap mIcon_val;

    @Override
    public View getView(int pos, View convertView, ViewGroup container) {
        // TODO Auto-generated method stub
        LayoutInflater inflater = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.grid_single, container,false);

        TextView list_tvprodname = (TextView)v.findViewById(R.id.grid_text);
        TextView list_tvprodprice = (TextView)v.findViewById(R.id.grid_price);
        ImageView list_prodimg = (ImageView)v.findViewById(R.id.grid_image);

        list_tvprodname.setText(prodnamelist.get(pos));
        list_tvprodprice.setText(prodpricelist.get(pos).toString());

            try {
                URL newurl = new URL("http://192.168.1.211:8080/EthnicIndianFashion/image/"+prodimgname1list.get(pos));

                HttpURLConnection connection = (HttpURLConnection) newurl
                        .openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                mIcon_val= BitmapFactory.decodeStream(input);
                mIcon_val = Bitmap.createScaledBitmap(mIcon_val, 150, 170, false);//This is only if u want to set the image size.
                list_prodimg.setImageBitmap(mIcon_val);
            } catch (IOException e) {
                e.printStackTrace();
                System.out.printf("Exception", e.getMessage());
                return null;
            }


        return v;
    }

    public CustomAdapter3(Context c, ArrayList<String> prodnamelist,
						  ArrayList<String> prodimgname1list, ArrayList<Integer> prodpricelist) {
        super();
        this.c = c;
        this.prodnamelist = prodnamelist;
        this.prodpricelist = prodpricelist;
        this.prodimgname1list = prodimgname1list;

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return prodnamelist.size();
    }

    @Override
    public Object getItem(int pos) {
        // TODO Auto-generated method stub
        return prodnamelist.get(pos);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return prodnamelist.size();
    }


}
