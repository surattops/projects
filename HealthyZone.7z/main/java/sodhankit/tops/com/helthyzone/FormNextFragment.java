package sodhankit.tops.com.helthyzone;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.rengwuxian.materialedittext.MaterialEditText;
import com.rey.material.widget.Button;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class FormNextFragment extends Fragment implements ServerCallAsyncTask.OnAsyncJSONResponse{

    private static final int INSERTCUST_MST = 1;

    public FormNextFragment() {
        // Required empty public constructor
    }
    MaterialEditText etheight,etweight,etvisceralfat,etsubcutaneousfat,etbodyfat,etbodymetabolicage,
            etbodymassindex,etbodymetabolicrate,etmusclemass;
    Button btsubmitform;

String  id;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_form_next, container, false);

        Bundle bundle = getArguments();
        id = bundle.getString("ID");

        etheight = (MaterialEditText)view.findViewById(R.id.etheight);
        etweight = (MaterialEditText)view.findViewById(R.id.etweight);
        etvisceralfat = (MaterialEditText)view.findViewById(R.id.etvisceralfat);
        etsubcutaneousfat = (MaterialEditText)view.findViewById(R.id.etsubcutaneousfat);
        etbodyfat = (MaterialEditText)view.findViewById(R.id.etbodyfat);
        etbodymetabolicage = (MaterialEditText)view.findViewById(R.id.etbodymetabolicage);
        etbodymassindex = (MaterialEditText)view.findViewById(R.id.etbodymassindex);
        etbodymetabolicrate = (MaterialEditText)view.findViewById(R.id.etbodymetabolicrate);
        etmusclemass = (MaterialEditText)view.findViewById(R.id.etmusclemass);

        btsubmitform = (Button)view.findViewById(R.id.btnsubmitform);


        btsubmitform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String height=etheight.getText().toString();
                String weight =etweight.getText().toString();
                String visceralfat =etvisceralfat.getText().toString();
                String subcutaneousfat =etsubcutaneousfat.getText().toString();
                String bodyfat =etbodyfat.getText().toString();
                String bodymetabolicage =etbodymetabolicage.getText().toString();
                String bodymassindex =etbodymassindex.getText().toString();
                String bodymetabolicrate =etbodymetabolicrate.getText().toString();
                String musclemass =etmusclemass.getText().toString();

                final String url = Customer_data.BASE_URL + Customer_data.INSERT;

                HashMap<String,String> hashMap = new HashMap<String, String>();
                hashMap.put("Cust_id",id);
                hashMap.put("Cust_height",height);
                hashMap.put("Cust_weight",weight);
                hashMap.put("Cust_viscral_fat",visceralfat);
                hashMap.put("Sub_cutaneous_fat",subcutaneousfat);
                hashMap.put("Body_fat",bodyfat);
                hashMap.put("Body_metabclic_age",bodymetabolicage);
                hashMap.put("Body_mass_index",bodymassindex);
                hashMap.put("Body_metabolic_rate",bodymetabolicrate);
                hashMap.put("Muscle_mass",musclemass);




                ServerCallAsyncTask asyncTask = new ServerCallAsyncTask(FormNextFragment.this,getActivity(),url,hashMap,INSERTCUST_MST);
                asyncTask.execute();
            }
        });

        return view;
    }

    @Override
    public void asyncGetSMSResponse(String response, int flag)
    {
        if (flag ==INSERTCUST_MST)
        {
            Toast.makeText(getActivity(),"Data Saved",Toast.LENGTH_LONG).show();
            if (response.trim().length() > 0)
            {
                //Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                Recycle_Fragment fragment = new Recycle_Fragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Recycle_Fragment.class.getName())
                        .replace(R.id.content_nevigation, fragment)
                        .commit();
            }
            else
            {
                Toast.makeText(getActivity(), "Failed To save Data!!!", Toast.LENGTH_SHORT).show();
            }

        }
    }
}
