package sodhankit.tops.com.helthyzone;

/**
 * Created by Pratik Lakkad on 07-03-2017.
 */

public class Customer_data {

    public static final String BASE_URL = "http://192.168.43.126/admin/customer.php?";

    public static final String SELECT = "selectcustomer";

    public static final String INSERT = "insertcustomer_mst";

    public static final String UPDATE = "deletecustomer_mst";

    public static final String DELETE = "updatecustomer_mst";
}
