package sodhankit.tops.com.digitalsociety.model;

/**
 * Created by Admin on 3/7/2017.
 */

public class Member {

    private String name;
    private String password;
    private String contact;
    private String apartment_number;
    private String noOfMember;
    private String typeMember;
    private String committeeId;
    private int noOfVehicle;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getApartment_number() {
        return apartment_number;
    }

    public void setApartment_number(String apartment_number) {
        this.apartment_number = apartment_number;
    }

    public String getNoOfMember() {
        return noOfMember;
    }

    public void setNoOfMember(String noOfMember) {
        this.noOfMember = noOfMember;
    }

    public String getTypeMember() {
        return typeMember;
    }

    public void setTypeMember(String typeMember) {
        this.typeMember = typeMember;
    }

    public String getCommitteeId() {
        return committeeId;
    }

    public void setCommitteeId(String committeeId) {
        this.committeeId = committeeId;
    }

    public int getNoOfVehicle() {
        return noOfVehicle;
    }

    public void setNoOfVehicle(int noOfVehicle) {
        this.noOfVehicle = noOfVehicle;
    }


}
