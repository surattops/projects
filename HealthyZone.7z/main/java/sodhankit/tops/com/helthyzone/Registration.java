package sodhankit.tops.com.helthyzone;

/**
 * Created by Pratik Lakkad on 23-02-2017.
 */

public class Registration {


    //public static final String BASE_URL = "http://192.168.43.126/admin/registrationmst.php?";
    public static final String BASE_URL = "http://192.168.1.226:8080/user/registrationmst.php?";
    public static final String BASE_URL_A = "http://192.168.1.226:8080/user/attendence.php?";
    public static final String SELECT = "selectall";

    public static final String INSERT = "insertregistration_mst";
    public static final String INSERT_ATTENDANCE = "insertattendence_mst";

    public static final String UPDATE = "updateregistration_mst";

    public static final String DELETE = "deleteregistration_mst";

}
