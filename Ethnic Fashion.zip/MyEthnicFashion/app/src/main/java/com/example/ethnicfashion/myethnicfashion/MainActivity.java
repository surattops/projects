package com.example.ethnicfashion.myethnicfashion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUserName;
    private EditText editTextPassword;
    int f=0;
    public static final String USER_NAME = "USERNAME";

    String username;
    String password;
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUserName = (EditText) findViewById(R.id.editTextUserName);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);

        Button btn = (Button)findViewById(R.id.btnlogin);
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String etuser=editTextUserName.getText().toString();
                String etpass=editTextPassword.getText().toString();

                callWebService("http://192.168.1.211:8080/webservice1/wb1.php?username="+etuser+"&userpassword="+etpass);




            }

        });
    }

    void callWebService(String url)
    {
        (new AsyncTask<String, Void, String>()
        {
            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd=ProgressDialog.show(MainActivity.this,"Wait","Loading");
            }

            @Override
            protected String doInBackground(String... params) {
                JSONParser jp = new JSONParser();
                String jstring = jp.getJSONData(params[0]);
                return jstring;
            }

            @Override
            protected void onPostExecute(String jstring) {
                super.onPostExecute(jstring);
                pd.dismiss();
               // Log.i("JsonString",jstring);
                try {
                    JSONObject login = new JSONObject(jstring);
                    JSONArray jarray =  login.getJSONArray("username");
                    for (int i = 0; i < jarray.length(); i++) {
                        JSONObject user = jarray.getJSONObject(i);
                        String su=user.getString("username");
                        String su1=user.getString("userpassword");
                        Log.i("User", su);

                        Intent i1 = new Intent(MainActivity.this,CategoryActivity.class);
                        startActivity(i1);

                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    Log.i("Error", e.toString());
                }
            }
        }).execute(url);

    }
}
