package sodhankit.tops.com.helthyzone;

/**
 * Created by Pratik Lakkad on 22-02-2017.
 */

public class Customer {


    private String Cust_id;
    private String Cust_name;
    private String Cust_age;
    private String DOB;
    private String Cust_gender;
    private String Reference;
    private String Cust_pno;


    public String getCust_id()

    {

        return Cust_id;
    }

    public void setCust_id(String cust_id)
    {
        Cust_id = cust_id;
    }

    public String getCust_name()
    {
        return Cust_name;
    }

    public void setCust_name(String cust_name)
    {
        Cust_name = cust_name;
    }

    public String getCust_age()
    {
        return Cust_age;
    }

    public void setCust_age(String cust_age)
    {
        Cust_age = cust_age;
    }

    public String getDOB()
    {
        return DOB;
    }

    public void setDOB(String DOB)
    {
        this.DOB = DOB;
    }

    public String getCust_gender()
    {
        return Cust_gender;
    }

    public void setCust_gender(String cust_gender)
    {
        Cust_gender = cust_gender;
    }

    public String getReference()
    {
        return Reference;
    }

    public void setReference(String reference)
    {
        Reference = reference;
    }

    public String getCust_pno()
    {
        return Cust_pno;
    }

    public void setCust_pno(String cust_pno)
    {
        Cust_pno = cust_pno;
    }

    @Override
    public String toString()
    {
        return Cust_id+"--"+Cust_name+"--"+Cust_age+"--"+Cust_gender+"--"+Cust_pno;
    }
}
