package sodhankit.tops.com.digitalsociety.memberpanel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import sodhankit.tops.com.digitalsociety.R;
import sodhankit.tops.com.digitalsociety.model.Complain;


/**
 * A simple {@link Fragment} subclass.
 */
public class ComplainFragment extends Fragment {


    RecyclerView recyclerView;


    public ComplainFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        View view=inflater.inflate(R.layout.fragment_complain, container, false);
        // Inflate the layout for this fragment
        initView(view);
        //getAllComplain();
        return view;
    }

   /* private void getAllComplain() {
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference()
                .child("complain");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                ArrayList<Complain> complainArrayList=new ArrayList<Complain>();
                for (DataSnapshot complainSnapshot: dataSnapshot.getChildren()) {
                    Complain complain = complainSnapshot.getValue(Complain.class);
                    complainArrayList.add(complain);
                }
                Toast.makeText(getActivity(), complainArrayList.toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }*/

    private void initView(View view) {
        recyclerView=(RecyclerView)view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);
        DatabaseReference mDatabaseRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference childRef = mDatabaseRef.child("complain");

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        final FirebaseRecyclerAdapter<Complain, ComplainViewHolder> mAdapter = new FirebaseRecyclerAdapter<Complain, ComplainViewHolder>(Complain.class,
                R.layout.complain_row_item, ComplainViewHolder.class, childRef) {
                    @Override
                    protected void populateViewHolder(ComplainViewHolder viewHolder,
                                                      Complain model, final int position) {
                        viewHolder.nameText.setText(model.getTitle());
                        viewHolder.messageText.setText(model.getDescription());

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Log.w("COMPLAIN", "You clicked on "+position);
                               // mAdapter.getRef(position).removeValue();

                            }
                        });
                    }
        };
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        getActivity().getMenuInflater().inflate(R.menu.member_main,menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.action_add:
                Fragment fragment=new NewComplaintFragment();
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout,fragment)
                        .addToBackStack(ComplainFragment.class.getName())
                        .commit();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
