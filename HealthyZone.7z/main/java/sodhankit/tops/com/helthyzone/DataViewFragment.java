package sodhankit.tops.com.helthyzone;


import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class DataViewFragment extends Fragment implements ServerCallAsyncTask.OnAsyncJSONResponse{

    private static final int CUST_DATA = 1;
    TableLayout tablelayout;

    public DataViewFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_data_view, container, false);
        tablelayout = (TableLayout)view.findViewById(R.id.drawer_layout);
        addHeaderRow();

        String id=getArguments().getString("ID");

        String url=Customer_data.BASE_URL+Customer_data.SELECT;
        HashMap<String, String> hashMap=new HashMap<>();
        hashMap.put("id",id);
        ServerCallAsyncTask asyncTask=new ServerCallAsyncTask(DataViewFragment.this,getActivity(),url,hashMap,CUST_DATA);
        asyncTask.execute();

        return view;
    }

    private void addHeaderRow()
    {
        TableRow tr = new TableRow(getActivity());
        tr.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
        TextView tvTxnDate = getTextView("Height", -1,true,R.drawable.header_background);
        tr.addView(tvTxnDate);

        TextView tvDatVal = getTextView("Weight", -1,true,R.drawable.header_background);
        tr.addView(tvDatVal);

        TextView tvNarration = getTextView("ViscralFat", -1,true,R.drawable.header_background);
        tr.addView(tvNarration);

        TextView tvDebit = getTextView("CutaneousFat.", -1,true,R.drawable.header_background);
        tr.addView(tvDebit);

        TextView tvCredit = getTextView("BodyFat", -1,true,R.drawable.header_background);
        tr.addView(tvCredit);

        TextView tvMetabolic = getTextView("MetabolicAge", -1,true,R.drawable.header_background);
        tr.addView(tvMetabolic);

        TextView tvMassIndex = getTextView("MassIndex", -1,true,R.drawable.header_background);
        tr.addView(tvMassIndex);

        TextView tvMetabolicRate = getTextView("MetabolicRate", -1,true,R.drawable.header_background);
        tr.addView(tvMetabolicRate);

        TextView tvMuscle = getTextView("MuscleMass", -1,true,R.drawable.header_background);
        tr.addView(tvMuscle);

        TextView tvDate = getTextView("DateChecking", -1,true,R.drawable.header_background);
        tr.addView(tvDate);

        tablelayout.addView(tr, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT));

    }

    public TextView getTextView(String value, int count,boolean boldFlag,int background)
    {
        TextView textview = new TextView(getActivity());
        textview.setLayoutParams(new TableRow.LayoutParams(
                 TableRow.LayoutParams.WRAP_CONTENT,TableRow.LayoutParams.WRAP_CONTENT));
        textview.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
        if(count!=-1)
            textview.setId(200 + count);
        textview.setText(value);
        textview.setTextColor(Color.BLACK);
        if(boldFlag)
            textview.setTypeface(Typeface.DEFAULT_BOLD);
        textview.setBackgroundResource(background);
        return textview;
    }


    @Override
    public void asyncGetSMSResponse(String response, int flag) {
        if(flag== CUST_DATA)
        {
            try {
                JSONObject jsonObject=new JSONObject(response);
                JSONArray jsonArray=jsonObject.getJSONArray("data");
                addrows(jsonArray);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }

    private void addrows(JSONArray jsonArray) throws JSONException {
        int count=200;
        for(int k=0;k<jsonArray.length();k++) {
            JSONObject jsonObject=jsonArray.getJSONObject(k);
            TableRow tr = new TableRow(getActivity());
            tr.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));

            TextView cutHeight = getTextView(jsonObject.getString("cust_height"), count,false,R.drawable.cell_background);
            cutHeight.setClickable(true);
            tr.addView(cutHeight);

            TextView custWeight = getTextView(jsonObject.getString("cust_weight"), count,false,R.drawable.cell_background);
            tr.addView(custWeight);

            TextView custViscralFat = getTextView(jsonObject.getString("cust_viscral_fat"), count,false,R.drawable.cell_background);
            tr.addView(custViscralFat);


            TextView subCutaneousFat = getTextView(jsonObject.getString("sub_cutaneous_fat"), count,false,R.drawable.cell_background);
            tr.addView(subCutaneousFat);

            TextView bodyFat = getTextView(jsonObject.getString("body_fat"), count,false,R.drawable.cell_background);
            tr.addView(bodyFat);

            TextView bodyMetabclicAge = getTextView(jsonObject.getString("body_metabolic_age"), count,false,R.drawable.cell_background);
            tr.addView(bodyMetabclicAge);

            TextView bodyMassIndex = getTextView(jsonObject.getString("body_mass_index"), count,false,R.drawable.cell_background);
            tr.addView(bodyMassIndex);

            TextView bodyMetabolicRate = getTextView(jsonObject.getString("body_metabolic_rate"), count,false,R.drawable.cell_background);
            tr.addView(bodyMetabolicRate);

            TextView muscleMass = getTextView(jsonObject.getString("muscle_mass"), count,false,R.drawable.cell_background);
            tr.addView(muscleMass);

            TextView dateChecking = getTextView(jsonObject.getString("date_checking"), count,false,R.drawable.cell_background);
            tr.addView(dateChecking);

            tablelayout.addView(tr, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT));
        }
    }
}
