package sodhankit.tops.com.helthyzone;


import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.rey.material.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class Attendance_Fragment extends Fragment
        implements ServerCallAsyncTask.OnAsyncJSONResponse{

    private static final int ATTENDANCE = 2;
    SwipeMenuListView listview;
    ImageButton imgbtn;
    ArrayList<Customer> CustomerArrayList;
    AdapterDetails adapter;
    public static ArrayList<String> custId;


    private static final int Select_All = 1;

    public Attendance_Fragment() {
        // Required empty public constructor
    }


    private void initSwipMenu()
    {
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "open" item
                SwipeMenuItem openItem = new SwipeMenuItem(
                        getActivity());
                // set item background
                openItem.setBackground(new ColorDrawable(Color.rgb(0xC9, 0xC9,
                        0xCE)));
                // set item width
                openItem.setWidth(50);
                // set item title
                openItem.setTitle("Open");
                // set item title fontsize
                openItem.setTitleSize(18);
                // set item title font color
                openItem.setTitleColor(Color.WHITE);
                // add to menu
                menu.addMenuItem(openItem);

                // create "delete" item
                SwipeMenuItem viewItem = new SwipeMenuItem(
                        getActivity());
                // set item background
                viewItem.setBackground(new ColorDrawable(Color.rgb(0xC9,
                        0xC9, 0xCE)));
                // set item width
                viewItem.setWidth(60);
                viewItem.setTitle("View");

                //deleteItem.setIcon(android.R.drawable.ic_menu_delete);
                // add to menu
                viewItem.setTitleSize(18);
                // set item title font color
                viewItem.setTitleColor(Color.WHITE);
                // add to menu

                menu.addMenuItem(viewItem);
            }
        };

// set creator
        listview.setMenuCreator(creator);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                            final Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recycle_, container, false);

        listview = (SwipeMenuListView) view.findViewById(R.id.listview);
        initSwipMenu();
        listview.setSwipeDirection(SwipeMenuListView.DIRECTION_LEFT);
        listview.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                Customer customer= CustomerArrayList.get(position);
                Bundle bundle = new Bundle();
                switch (index)
                {
                    case 0:
                        Toast.makeText(getContext(),"Edit",Toast.LENGTH_LONG).show();
                        bundle.putString("ID",customer.getCust_id());
                        FormNextFragment fragment = new FormNextFragment();
                        fragment.setArguments(bundle);

                        getActivity()
                                .getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.content_nevigation,fragment)
                                .commit();
                        break;

                    case 1:
                        bundle.putString("ID",customer.getCust_id());

                        DataViewFragment fragments =  new DataViewFragment();
                        fragments.setArguments(bundle);

                        getActivity().
                                getSupportFragmentManager().
                                beginTransaction().
                                addToBackStack(Attendance_Fragment.class.getName())
                                .replace(R.id.content_nevigation,fragments).
                                commit();

                        break;
                }
                return false;
            }
        });


        final String url = Registration.BASE_URL + Registration.SELECT;


        HashMap<String,String> hashMap=new HashMap();

        ServerCallAsyncTask asyncTask=new ServerCallAsyncTask(Attendance_Fragment.this,getActivity(),url,hashMap,Select_All);
        asyncTask.execute();

        imgbtn = (ImageButton) view.findViewById(R.id.imgbtn);

        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*for(int i=0;i<adapter.getCount();i++)
                {
                    Customer customer=(Customer) adapter.getItem(i);
                    Toast.makeText(getActivity(), customer.getCust_name(), Toast.LENGTH_SHORT).show();
                }*/
               // Toast.makeText(getActivity(), custId.toString(), Toast.LENGTH_SHORT).show();
                if(custId.size()>0) {
                    String url = Registration.BASE_URL_A + Registration.INSERT_ATTENDANCE;
                    HashMap<String, String> hm = new HashMap<String, String>();
                    hm.put("ids", custId.toString());
                    ServerCallAsyncTask asyncTask = new ServerCallAsyncTask(Attendance_Fragment.this, getActivity(), url, hm, ATTENDANCE);
                    asyncTask.execute();
                }
            }
        });


        return view;
    }

    @Override
    public void asyncGetSMSResponse(String response, int flag)
    {
        if (flag == Select_All) {
            if (response.trim().length()>0) {
                try {
                    JSONObject jsonobject = new JSONObject(response);
                    JSONArray jsonarray = jsonobject.getJSONArray("data");
                    CustomerArrayList = new ArrayList<>();
                    for (int i = 0; i < jsonarray.length(); i++) {
                        JSONObject CustomerJson = jsonarray.getJSONObject(i);
                        Customer customer = new Customer();
                        customer.setCust_id(CustomerJson.getString("cust_id"));
                        customer.setCust_name(CustomerJson.getString("cust_name"));
                        customer.setCust_age(CustomerJson.getString("cust_age"));
                        customer.setCust_gender(CustomerJson.getString("cust_gender"));
                        customer.setCust_pno(CustomerJson.getString("cust_pno"));

                        CustomerArrayList.add(customer);

                    }
                    custId=new ArrayList<>();
                    adapter  = new AdapterDetails(CustomerArrayList,getActivity(),true);
                    listview.setAdapter(adapter);


                } catch (JSONException e)
                {
                    e.printStackTrace();
                }

            }
            else
            {
                Toast.makeText(getActivity(), "Failed to Show Data!!!", Toast.LENGTH_SHORT).show();
            }
    }
       else if (flag == ATTENDANCE) {
            Toast.makeText(getActivity(), "Attendance Success!!!", Toast.LENGTH_SHORT).show();
        }

 }


    public ArrayList<String> getCustId() {
        return custId;
    }

    public void setCustId(ArrayList<String> custId) {
        this.custId = custId;
    }
}