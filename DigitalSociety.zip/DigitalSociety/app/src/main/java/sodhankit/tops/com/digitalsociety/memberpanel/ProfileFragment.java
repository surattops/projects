package sodhankit.tops.com.digitalsociety.memberpanel;


import android.os.Bundle;
import android.support.annotation.IntegerRes;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import sodhankit.tops.com.digitalsociety.LoginFragment;
import sodhankit.tops.com.digitalsociety.R;
import sodhankit.tops.com.digitalsociety.model.Member;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment {

    Button btnRegister, btnLinkToLogin;
    EditText etFullName,etEmail,etContact, etPassword, etAptNumber, etNoOfMember,etNoOfVehicle,etCommitteeId;
    Spinner memberType;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_registration, container, false);
        // Inflate the layout for this fragment
        initView(view);
        return view;
    }

    private void initView(View view) {
        btnRegister=(Button)view.findViewById(R.id.btnRegister);
        btnLinkToLogin=(Button)view.findViewById(R.id.btnLinkToLoginScreen);

        etEmail=(EditText)view.findViewById(R.id.email);
        etFullName=(EditText)view.findViewById(R.id.name);
        etPassword=(EditText)view.findViewById(R.id.password);
        etContact=(EditText)view.findViewById(R.id.contact);
        etAptNumber=(EditText)view.findViewById(R.id.apartment_number);
        etNoOfMember=(EditText)view.findViewById(R.id.no_of_member);
        etNoOfVehicle=(EditText)view.findViewById(R.id.no_of_vehicle);
        etCommitteeId=(EditText)view.findViewById(R.id.committee_id);
        memberType=(Spinner)view.findViewById(R.id.type_member);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                /*String name = inputFullName.getText().toString().trim();
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();*/
                registerUser();
                /*if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                    registerUser();
                } else {
                    Toast.makeText(getActivity(),
                            "Please enter your details!", Toast.LENGTH_LONG)
                            .show();
                }*/
            }
        });

        // Link to Login Screen
        btnLinkToLogin.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Fragment fragment=new LoginFragment();
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout,fragment)
                        .commit();
            }
        });
    }

    private void registerUser() {
        Member member=new Member();
        member.setName(etFullName.getText().toString());
        member.setContact(etContact.getText().toString());
        member.setApartment_number(etAptNumber.getText().toString());
        member.setNoOfMember(etNoOfMember.getText().toString());
        member.setPassword(etPassword.getText().toString());
        member.setNoOfVehicle(Integer.parseInt(etNoOfVehicle.getText().toString()));
        member.setTypeMember(memberType.getSelectedItem().toString());
        member.setCommitteeId(etCommitteeId.getText().toString());

       // FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
       // DatabaseReference myRef = database.getReference("members");
        //mDatabase.child("users").child(userId).setValue(user);
        //myRef.setValue(member);
        mDatabase.child("members")
                .child(member.getContact()).setValue(member);

        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Member user = dataSnapshot.getValue(Member.class);
                Log.d("MEMBER", "Value is: " + user.getContact());
                Toast.makeText(getActivity(), "Registration Successfull...", Toast.LENGTH_SHORT).show();
               /* Fragment fragment=new LoginFragment();
                getFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame_layout,fragment)
                        .commit();*/
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Error", "Failed to read value.", error.toException());
            }
        });
    }

}
