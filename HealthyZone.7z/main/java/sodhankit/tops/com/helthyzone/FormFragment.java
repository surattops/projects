package sodhankit.tops.com.helthyzone;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.rengwuxian.materialedittext.MaterialEditText;
import com.rey.material.widget.Button;

import java.util.Calendar;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class FormFragment extends Fragment implements ServerCallAsyncTask.OnAsyncJSONResponse {

    private static final int INSERT_REGISTRATION = 1;

    public FormFragment() {
        // Required empty public constructor
    }



    Button btnnext;
    ImageButton ibcalender;
    MaterialEditText etrefrence,etentername,etage,etdob,etaddress,etphone,etemail,etmedication,etdiscomfort,etbreakfast,etlunch,etdinner
            ,ethowmany,etwaterconsum;

    RadioGroup rdgender;
    RadioButton rdmale,rdfemale;
    CheckBox chveg,chnonveg,chcoffee,chtea;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_form, container, false);
        // Inflate the layout for this fragment
        btnnext = (Button) view.findViewById(R.id.btnnext);
        ibcalender = (ImageButton) view.findViewById(R.id.ibcalender);
        etrefrence = (MaterialEditText) view.findViewById(R.id.etrefrenc);
        etentername = (MaterialEditText) view.findViewById(R.id.etentername);
        etage = (MaterialEditText) view.findViewById(R.id.etage);
        etdob = (MaterialEditText) view.findViewById(R.id.etdob);
        etaddress = (MaterialEditText) view.findViewById(R.id.etaddress);
        etphone = (MaterialEditText) view.findViewById(R.id.etphone);
        etemail = (MaterialEditText) view.findViewById(R.id.etemail);
        etmedication = (MaterialEditText) view.findViewById(R.id.etmedication);
        etdiscomfort = (MaterialEditText) view.findViewById(R.id.etdescomfort);
        etbreakfast = (MaterialEditText) view.findViewById(R.id.etbreakfast);
        etlunch = (MaterialEditText) view.findViewById(R.id.etlunch);
        etdinner = (MaterialEditText) view.findViewById(R.id.etdinner);
        ethowmany = (MaterialEditText) view.findViewById(R.id.ethowmany);
        etwaterconsum = (MaterialEditText) view.findViewById(R.id.etwaterconsum);

        rdgender = (RadioGroup) view.findViewById(R.id.rdgender);
        rdmale = (RadioButton) view.findViewById(R.id.rdmale);
        rdfemale = (RadioButton) view.findViewById(R.id.rdfemale);

        chveg = (CheckBox) view.findViewById(R.id.chveg);
        chnonveg = (CheckBox) view.findViewById(R.id.chnonveg);
        chcoffee = (CheckBox) view.findViewById(R.id.chcoffee);
        chtea = (CheckBox) view.findViewById(R.id.chtea);



        ibcalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    showDatePickerDialog();
            }
        });



        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                if(etrefrence.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter Reference",Toast.LENGTH_LONG).show();
                    etrefrence.setError("Please Enter Reference");
                    return;
                }
                String reference =etrefrence.getText().toString();
                String name =etentername.getText().toString();
                if(etentername.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter Name",Toast.LENGTH_LONG).show();
                    etentername.setError("Please Enter Name");
                    return;
                }
                String age =etage.getText().toString();
                if(etage.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter age",Toast.LENGTH_LONG).show();
                    etage.setError("Please enter age");
                    return;
                }
                String dob =etdob.getText().toString();
                if(etdob.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter DOB",Toast.LENGTH_LONG).show();
                    etdob.setError("Please Enter DOB");
                    return;
                }

                String Gender="";
                if(rdgender.getCheckedRadioButtonId()==R.id.rdgender){
                    Gender="Male";
                }else
                {
                    Gender="Female";
                }
                String address =etaddress.getText().toString();
                if(etaddress.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter address",Toast.LENGTH_LONG).show();
                    etaddress.setError("Please Enter address");
                    return;
                }
                String phone =etphone.getText().toString();
                if(etphone.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter phoneNo",Toast.LENGTH_LONG).show();
                    etphone.setError("Please Enter phoneNo");
                    return;
                }
                String email =etemail.getText().toString();
                if(etemail.getText().toString().length()==0)
                {
                    Toast.makeText(getContext(),"Please Enter email",Toast.LENGTH_LONG).show();
                    etemail.setError("Please Enter email");
                    return;
                }

                String medication =etmedication.getText().toString();
                String discomfort =etdiscomfort.getText().toString();
                String breakfast =etbreakfast.getText().toString();
                String lunch =etlunch.getText().toString();
                String dinner =etdinner.getText().toString();
                String water =etwaterconsum.getText().toString();

                final String url = Registration.BASE_URL + Registration.INSERT;


                HashMap<String,String> hashMap=new HashMap<String, String>();
                hashMap.put("Reference",reference);
                hashMap.put("Cust_name",name);
                hashMap.put("Cust_age",age);
                hashMap.put("DOB",dob);
                hashMap.put("Cust_add",address);
                hashMap.put("Cust_pno",phone);
                hashMap.put("Cust_email",email);
                hashMap.put("Cust_gender", Gender);
                hashMap.put("Medication",medication);
                hashMap.put("Discomfort",discomfort);
                hashMap.put("Daily_diets",breakfast);
                hashMap.put("Daily_diets",lunch);
                hashMap.put("Daily_diets",dinner);
                hashMap.put("Water_consum",water);


                ServerCallAsyncTask asyncTask=new ServerCallAsyncTask(FormFragment.this,getActivity(),url,hashMap,INSERT_REGISTRATION);
                asyncTask.execute();

            }
        });


        return view;
    }

    private void showDatePickerDialog() {

        Calendar calendar=Calendar.getInstance();
        int year=calendar.get(Calendar.YEAR);
        int month=calendar.get(Calendar.MONTH);
        int dayOfMonth=calendar.get(Calendar.DAY_OF_MONTH);

     new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
         @Override
         public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
             etdob.setText(dayOfMonth +"/" + (month + 1) + "/" + year);
         }
     },year,month,dayOfMonth).show();

    }


    @Override
    public void asyncGetSMSResponse(String response, int flag) {
        if (flag ==INSERT_REGISTRATION)
        {
            Toast.makeText(getActivity(),"Data Saved",Toast.LENGTH_LONG).show();
            if (response.trim().length() > 0)
            {
                //Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                Recycle_Fragment fragment = new Recycle_Fragment();
                getActivity()
                        .getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack(Recycle_Fragment.class.getName())
                        .replace(R.id.content_nevigation, fragment)
                        .commit();
            }
            else
            {
                Toast.makeText(getActivity(), "Registration Failed!!!", Toast.LENGTH_SHORT).show();
            }

        }
    }
}
