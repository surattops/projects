<?php  
mysql_connect("localhost","root",""); 
mysql_select_db("ethnicindianfashion"); 
//code to select all the fields from user table 

if(isset($_REQUEST["catid"])) 
{ 
	$catid = $_REQUEST['catid'];
  $sel = "select * from subcategory where catid = $catid"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $subcategory["subcategory"][] = $fet;  
  } 
  echo json_encode($subcategory); 
} 

if(!empty($_REQUEST['userid'])&&!empty($_REQUEST['prodid'])) 
{ 
  $userid = $_REQUEST['userid']; 
  $prodid = $_REQUEST['prodid']; 
  $ins = "insert into cart(prodid,userid) values('$userid','$prodid')"; 
  mysql_query($ins)or die(mysql_query()); 
   
} 

if(isset($_REQUEST["all"])) 
{ 
  $sel = "select * from category"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $category["category"][] = $fet;  
  } 
  echo json_encode($category); 
} 

if(isset($_REQUEST["allcolor"])) 
{ 
  $sel = "select * from color"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $color["color"][] = $fet;  
  } 
  echo json_encode($color); 
} 


if(isset($_REQUEST["lastproduct"])) 
{ 
  $sel = "select * from product ORDER BY prodid DESC LIMIT 0 , 3"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 


if(isset($_REQUEST["product"])) 
{ 
  $sel = "select * from product"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 


if(isset($_REQUEST["prodid"])) 
{ 
$prodid = $_REQUEST['prodid'];
  $sel = "SELECT * 
FROM product, color, size, fabric, brand
WHERE product.cid = color.cid
AND product.sid = size.sid
AND product.fabid = fabric.fabid
AND product.bid = brand.bid
AND product.prodid = $prodid"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 

if(isset($_REQUEST["prodname"])) 
{ 
$prodname = $_REQUEST['prodname'];
  $sel = "SELECT * 
FROM product, color, size, fabric, brand
WHERE product.cid = color.cid
AND product.sid = size.sid
AND product.fabid = fabric.fabid
AND product.bid = brand.bid
AND product.prodname = '$prodname'"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 

if(isset($_REQUEST["cattid"])) 
{ 
	$catid = $_REQUEST['cattid'];
		$subcatid = $_REQUEST['subcatid'];
 
 
  $sel = "select * from product where catid = $catid and subcatid = $subcatid"; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 

if(isset($_REQUEST["login"]))
{ 
 
	$query1 = "SELECT userusername,userpassword FROM user"; 
	  $res1 = mysql_query($query1); 
  while($fet1 = mysql_fetch_assoc($res1)) 
  { 
    $user["user"][] = $fet1;  
  } 
  echo json_encode($user); 

}




if(!empty($_REQUEST['username'])&&!empty($_REQUEST['userpassword'])) 
{ 
  $username = $_REQUEST['username']; 
  $password = $_REQUEST['userpassword']; 
  $query1 = "SELECT * FROM user where username = '$username' and userpassword = '$password'";
 
 $res1 = mysql_query($query1); 
  while($fet1 = mysql_fetch_assoc($res1)) 
  { 
    $user["username"][] = $fet1;  
  } 
  echo json_encode($user);  
} 
if(!empty($_REQUEST['delid'])) 
{ 
  $id = $_REQUEST['delid']; 
  $del = "delete from user where id=$id"; 
  mysql_query($del)or die(mysql_error()); 
   
} 




if(!empty($_REQUEST['userid'])&&!empty($_REQUEST['ansid'])) 
{ 
  $userid = $_REQUEST['userid']; 
  $ansid = $_REQUEST['ansid'];
   
  $ins1 = "insert into result(userid,ansid)values('$userid','$ansid')"; 
  mysql_query($ins1)or die(mysql_query()); 
} 


if(isset($_REQUEST["descprice"])) 
{ 
  $sel = "SELECT * 
FROM product
ORDER BY prodprice DESC "; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 

if(isset($_REQUEST["ascprice"])) 
{ 
  $sel = "SELECT * 
FROM product
ORDER BY prodprice aSC "; 
  
  $res = mysql_query($sel); 
  while($fet = mysql_fetch_assoc($res)) 
  { 
    $product["product"][] = $fet;  
  } 
  echo json_encode($product); 
} 


 
?> 