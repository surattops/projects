package sodhankit.tops.com.digitalsociety.memberpanel;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import sodhankit.tops.com.digitalsociety.R;

/**
 * Created by Admin on 3/15/2017.
 */

public class ComplainViewHolder extends RecyclerView.ViewHolder {

    TextView nameText,messageText;
    View mView;

    public ComplainViewHolder(View itemView) {
        super(itemView);
        mView=itemView;
        nameText=(TextView)itemView.findViewById(R.id.text1);
        messageText=(TextView)itemView.findViewById(R.id.text2);
    }
}
