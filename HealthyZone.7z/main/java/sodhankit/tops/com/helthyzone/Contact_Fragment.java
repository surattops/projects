package sodhankit.tops.com.helthyzone;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Contact_Fragment extends Fragment {

    TextView tvadd,tvphone;
    public Contact_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_contact_, container, false);

        tvadd = (TextView)view.findViewById(R.id.tvadd);
        tvphone = (TextView)view.findViewById(R.id.tvphone);

        tvphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callintent = new Intent(Intent.ACTION_CALL);
               // callintent.putExtra(Intent.EXTRA_SUBJECT,"CALL NOW");
                startActivity(callintent);

            }
        });
        tvadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Intent intent = new Intent(getActivity(),MapsActivity.class);
                startActivity(intent);*/
            }
        });



        return view;
    }

}
