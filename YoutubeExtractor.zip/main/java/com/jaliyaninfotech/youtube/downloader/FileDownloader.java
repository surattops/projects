package com.jaliyaninfotech.youtube.downloader;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.content.Context.DOWNLOAD_SERVICE;

public class FileDownloader {
        private static final int  MEGABYTE = 1024 * 1024;

        public static void downloadFile(String fileUrl, File directory){
            try {

                URL url = new URL(fileUrl);
                HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();                
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                FileOutputStream fileOutputStream = new FileOutputStream(directory);
                int totalSize = urlConnection.getContentLength();

                byte[] buffer = new byte[MEGABYTE];
                int bufferLength = 0;
                while((bufferLength = inputStream.read(buffer))>0 ){
                    fileOutputStream.write(buffer, 0, bufferLength);
                }
                fileOutputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    public static long DownloadData (String uri, Context context) {

        long downloadReference;

        // Create request for android download manager
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(uri));

        //Setting title of request
        request.setTitle("Video Download");

        //Setting description of request
        request.setDescription("Youtube Video downloading...");

        //Set the local destination for the downloaded file to a path
        //within the application's external files directory
      /*  if(v.getId() == R.id.DownloadMusic)
            request.setDestinationInExternalFilesDir(MainActivity.this,
                    Environment.DIRECTORY_DOWNLOADS,"AndroidTutorialPoint.mp3");
        else if(v.getId() == R.id.DownloadImage)
            request.setDestinationInExternalFilesDir(MainActivity.this,
                    Environment.DIRECTORY_DOWNLOADS,"AndroidTutorialPoint.jpg");*/

        //Enqueue download and save into referenceId
        downloadReference = downloadManager.enqueue(request);

       /* Button DownloadStatus = (Button) findViewById(R.id.DownloadStatus);
        DownloadStatus.setEnabled(true);
        Button CancelDownload = (Button) findViewById(R.id.CancelDownload);
        CancelDownload.setEnabled(true);*/

        return downloadReference;
    }
}